/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.characterstream2;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Lab5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s = new Scanner(System.in);
        System.out.println("Enter your name :");
        String name = s.nextLine();
        System.out.println("Hello" + name);
        System.out.println("Enter your weight :");
        double w = s.nextDouble();
        System.out.println("weight = " + w);
        System.out.println("Enter your height :");
        double h = s.nextDouble();
        System.out.println("height = " + h);
        System.out.println(w*h);
        
    }
    
}
